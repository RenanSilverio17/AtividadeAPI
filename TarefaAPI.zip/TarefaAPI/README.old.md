# forum

## Entregas do Projeto Fórum

#### Dia 30/08 - 04/09

##### Entregar:
###### Api de Login;
###### Autenticação do usuário;
###### Rotas das páginas funcionando, com validação de autenticação do usuário. 