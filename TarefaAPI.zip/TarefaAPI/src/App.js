import { useState } from "react";
import Rotas from "./rotas/Rotas";

function Rotas(){
    const [news, setNew] = useState([])

    return(
        <>
        <Rotas news={news} setNews={setNews}/>
        </>
    )
}

export default App;