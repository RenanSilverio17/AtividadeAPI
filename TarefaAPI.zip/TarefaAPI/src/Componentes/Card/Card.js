
function Rotas(props){

    return(
        <>
        Home
        </>
    )
}

export default Card