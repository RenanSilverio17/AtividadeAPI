const news = [
    {
      id: 1,
      title: 'Manchete 1',
      content: 'Conteúdo da notícia 1',
    },
    {
      id: 2,
      title: 'Manchete 2',
      content: 'Conteúdo da notícia 2',
    },
  ];
  
  module.exports = news;
  